#include <iostream>

#include "notacionpolaca.h"

using namespace std;


//validar que almenos los parentesis esten apareados
//O NO ESTE EL PAR CORRESPONDIENTE
int main()
{

    string eInfija="((1-8)+3*5";

    return 0;
}
