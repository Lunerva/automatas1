#include "notacionpolaca.h"

NotacionPolaca::NotacionPolaca()
{

}

//IMPLEMENTAR METODO PARA CONTAR LA CANTIDAD DE PARENTESIS

char *NotacionPolaca::convertirAposfija(string expInfija)
{
    char *expPosFija = new char[expInfija.length()];

    //IMPLEMENTAR UN METODO PARA DETERMINAR
    //LA CANTIDAD DE OPERADORES ENLA EXPRESION INFIJA
    pilaT <int> *stack = new pilaT<int>(expInfija.length());


}

Simbolo NotacionPolaca::tipoYprocedencia(char c)
{

}

bool NotacionPolaca::validarEntrada(string entrada)
{
    int cont=0;
    int contOp=0;
    if(numParentesis(entrada)){
        for(int i=0;i<entrada.length();i++){
            if((entrada.at(i)>=42) && (entrada.at(i)<=45)){
                contOp++;
            }
            if((entrada.at(i)>=48) && (entrada.at(i)<=57)){
                cont++;
            }
            if(entrada.at(i)==94){
                contOp++;
            }
        }
    }
    cont+=contOp;
    if(cont==entrada.length()){
        return true;
    }
    return false;
}

bool NotacionPolaca::numParentesis(string entrada)
{
    int contIzq=0;
    int contDer=0;
    int contGen=0;

    for(int i=0;i<entrada.length();i++){
        if((entrada.at(i)==')') && (contIzq==0)){
            return false;
        }else{
            if(entrada.at(i)=='('){
                contIzq++;
                contGen++;
            }
            if(entrada.at(i)==')'){
                contDer++;
                contGen--;
                if(contGen<0){
                    return false;
                }
            }
        }
    }
    if(contIzq == contDer){
        return true;
    }
    return false;
}
