#ifndef CONJUNTO_H
#define CONJUNTO_H

#include<iostream>

using namespace std;

//#define MAX 10

//const int MAX=10;

//enumero o doy nombre a los enteros
enum{MAX = 10};//por default inicia en cero

enum codigo{overflow, ok, existe, si, no};

class conjunto
{
public:
    //    int elementos[10];
        int elementos[MAX];
    //      int *elementos;
        int nelem;
//    conjunto();
    conjunto(int n=5);//constructor con argumentos por defecto

    //implemente elmetodo copiar un conjunto en otro
    conjunto(conjunto *t);//copiar

    ~conjunto(){cout<<"\t \a \nENTRA EL DESTRUCTOR\t"<<endl;}
//    void vacio(){nelem=0;}
    inline void vacio(){nelem=0;}


    //UYTILIZAR LA SOBRECARGA DE OPERADORES DONDE APLIQUE
    codigo asignar(int valor);

    conjunto& operator+=(int &);

    void agregar(int valor);

    bool pertenece(const int);
    int perteneceValor(int valor);
    void borrarElemento(int);
    conjunto operator-=(int valor);

    int posVacia();

    bool esIgual(conjunto *);
    bool esIgual(conjunto *A, conjunto *B);
    conjunto operator==(conjunto *);

    void mostrar();
    void mostrar(string);

    friend ostream& operator<<(ostream& os, const conjunto &);

    class conjunto unionC(conjunto *otro);
    class conjunto interseccionC(conjunto *otro);

};

#endif // CONJUNTO_H












