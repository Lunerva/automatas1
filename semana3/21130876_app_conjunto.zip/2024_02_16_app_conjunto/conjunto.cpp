#include "conjunto.h"


conjunto::conjunto(int n)
{
    nelem=n;
    //elementos = new int[n];
/*
    for(int i=0;i<nelem;i++){
        elementos[i]=255;
    }*/
}

conjunto::conjunto(conjunto *t)
{
    nelem=t->nelem;
    for(int i=0;i<nelem;i++)
        elementos[i] = t->elementos[i];
}

codigo conjunto::asignar(int valor)
{
    if(pertenece(valor)){
        return existe;
    }
    if(nelem<MAX){
        elementos[nelem++]=valor;
        //nelem++;
        return ok;
    }
    return overflow;
}

conjunto& conjunto::operator+=(int &valor)
{
    if(!pertenece(valor)){
           int pos = this->posVacia();
           this->elementos[pos] = valor;
       }
       return *this;
}

void conjunto::agregar(int valor)
{
    if(!pertenece(valor)){
        int pos = this->posVacia();
        this->elementos[pos]=valor;
    }
}

bool conjunto::pertenece(const int valor)
{
    for(int i=0;i<nelem;i++){
        if(elementos[i]==valor){
            return true;
        }
    }
    return false;
}

int conjunto::perteneceValor(int valor)
{
    for(int i=0;i<nelem;i++){
        if(elementos[i]==valor){
            return i;
        }else {
            return -1;
        }
    }
}

void conjunto::borrarElemento(int valor)
{
    for ( int i = 0; i < nelem; i++ ) {
        if ( elementos[i] == valor ) {
            for ( ; i < nelem; i++ ){
                elementos[i] = elementos[i+1];
            }
            ~nelem;
        }
    }
}

conjunto conjunto::operator-=(int valor)
{
    for ( int i = 0; i < nelem; i++ ) {
        if ( elementos[i] == valor ) {
            for ( ; i < nelem; i++ ){
                elementos[i] = elementos[i+1];
            }
            ~nelem;
        }
    }
}

int conjunto::posVacia()
{
    for(int i=0;i<this->nelem;i++){
        if(elementos[i]==0){
            return i;
        }
    }
    return -1;
}

bool conjunto::esIgual(conjunto *conj)
{
    int cont=0;

    for(int i=0;i<conj->nelem;i++){
        if(pertenece(conj->elementos[i])){
            cont++;
        }
    }

    if(cont>=nelem){
        return true;
    }
    return false;
}

bool conjunto::esIgual(conjunto *A, conjunto *B)
{
    if(A->nelem != B->nelem){
        return false;
    }
    for(int i=0;i<A->nelem;i++){
        if(! B->pertenece(A->elementos[i]) ){
            return false;
        }
    }
    return true;
}

conjunto conjunto::operator==(conjunto *B)
{
    if(this->nelem != B->nelem){
        return no;
    }
    for(int i=0;i<this->nelem;i++){
        if(! B->pertenece(this->elementos[i]) ){
            return no;
        }
    }
    return si;
}

void conjunto::mostrar()
{
    cout<<"{";
    for(int i=0;i<nelem;i++){
        cout<<elementos[i];
    }
}

void conjunto::mostrar(string set)
{
    cout<<endl<<set<<" = {";
    int i;
    for(i=0;i<this->nelem-1;i++){
        cout<<this->elementos[i]<<" , ";
    }
    if(nelem > 0){
        cout<<elementos[nelem-1];
    }
    cout<<"}";

}

conjunto conjunto::unionC(conjunto *otro)
{
    int nnelem=this->nelem+otro->nelem;
    conjunto res = new conjunto(nnelem);

    for(int i=0;i<this->nelem;i++){
        res.agregar(this->elementos[i]);
    }
    for(int i=0;i<otro->nelem;i++){
        res.agregar(otro->elementos[i]);
    }
    return res;
}

conjunto conjunto::interseccionC(conjunto *otro)
{
    int nnelem=0;
    for(int i=0;i<otro->nelem;i++){
        if(this->pertenece(otro->elementos[i])){
            nnelem++;
        }
    }
    conjunto res = new conjunto(nnelem);
    for(int i=0;i<otro->nelem;i++){
        if(this->pertenece(otro->elementos[i])){
            res.agregar(otro->elementos[i]);
        }
    }
    return res;
}


ostream& operator<<(ostream& os, const conjunto &conj){
    string cad = "";
    for (int i = 0; i < conj.nelem; i++) {
        cad += to_string(conj.elementos[i]);
        if (i < conj.nelem - 1) {
            cad += ", ";
        }
    }
    os << "conjunto: { " << cad << " }" << endl;
    return os;
}

























