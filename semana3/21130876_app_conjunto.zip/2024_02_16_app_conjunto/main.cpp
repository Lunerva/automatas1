#include <iostream>
#include "conjunto.h"


using namespace std;

int genRand(){
    return rand()%89+10;
}

int main()
{
    cout << "aplicacion conjuntos\t" << endl;
    conjunto *setA,*setB,*setC,*setD;

    setA = new conjunto();
    setA->vacio();

    setA->asignar(17);
    setA->asignar(3);
    setA->asignar(5);
    setA->asignar(9);

    setA->mostrar("setA");
    cout<<endl;
    //setA->borrarElemento(5);
    setA->mostrar("setA");
    cout<<"\a\a\a\a\a\a\a"<<endl;

    setB = new conjunto();
    setB->vacio();

    setB->asignar(9);
    setB->asignar(3);
    setB->asignar(7);
    setB->asignar(0);

    setB->mostrar("setB");

    cout<<"\n"<<setA->esIgual(setB)<<endl;

    cout<<"PRUEBA UNION E INTERSECCION"<<endl;
    cout<<"union"<<endl;
    setA->mostrar("setA");
    setB->mostrar("setB");
    setC = new conjunto(setA->unionC(setB));
    setC->mostrar("setC");
    cout<<"\ninterseccion"<<endl;
    setA->mostrar("setA");
    setB->mostrar("setB");
    setD = new conjunto(setA->interseccionC(setB));
    setD->mostrar("setD");


//////////////////////////////////////
/// //////////////////////////////////
///
///

    cout << "\n\n\naplicacion conjuntos\t" << endl;
    conjunto *conA,*conB,*conC,*conD;

    conA= new conjunto();
    conA->vacio();

    for(int i=0;i<conA->nelem;i++){
        conA += genRand();
    }

    cout<<conA;


    return 0;
}
